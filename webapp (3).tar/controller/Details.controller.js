sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/json/JSONModel",
  "sap/m/MessageToast",
  "sap/f/library",
  "sap/m/MessageBox"
], function (Controller, JSONModel, MessageToast, fLibrary, MessageBox) {
  "use strict";


  var LayoutType = fLibrary.LayoutType;
  return Controller.extend("project1.controller.Details", {
    onInit() {
      // formGeneral toggles editability
      var oEditModel = new JSONModel({ editable: false });
      this.getView().setModel(oEditModel, "formGeneral");

      // This is typically used to initialize or update the view based on navigation parameters.
      this.getOwnerComponent()
        .getRouter()
        .getRoute("Details")
        .attachPatternMatched(this._onObjectMatched, this);
    },


    // =======================================_onObjectMatched========================================================================

// Attach a handler to the "Details" route that gets triggered when the route pattern is matched.


    _onObjectMatched(oEvent) {
      var sPayload = oEvent.getParameter("arguments").branch;
      var oView = this.getView();

      var oEditBtn = oView.byId("btnEditGeneral");
      var oDeleteBtn = oView.byId("btnDelete");

      if (!sPayload || sPayload === "0") {
        this._sBranchPath = null;
        oEditBtn.setEnabled(false);
        oDeleteBtn.setEnabled(false);
        oView.setModel(new JSONModel({}), "branchModel");

        this.getView().getModel("formGeneral").setData({
          editable: false,
          parentEditable: false,
          childEditable: false,
          isParent: false  // default
        });
        return;
      }

      oEditBtn.setEnabled(true);
      oDeleteBtn.setEnabled(true);

      var oData = JSON.parse(decodeURIComponent(sPayload));
      this._sBranchPath = oData.path;

      var oBranchModel = new JSONModel({
        parentName: oData.parentName,
        branchName: oData.branchName,
        BranchCode: oData.BranchCode,
        LogonLanguage: oData.LogonLanguage,
        Description: oData.Description,
        ValidFrom: oData.ValidFrom,
        ValidTo: oData.ValidTo
      });
      oView.setModel(oBranchModel, "branchModel");

      // Set editability flags - editable false, and parent/child editable only determined on Edit
      this.getView().getModel("formGeneral").setData({
        editable: false,
        parentEditable: false,
        childEditable: false,
        isParent: oData.isParent  // store the flag to use on Edit
      });
    },

    // =======================================Edit=========================================================================================================
    onEdit() {
      var oFM = this.getView().getModel("formGeneral");
      var bEditable = !oFM.getProperty("/editable");
      var bIsParent = oFM.getProperty("/isParent");

      // Toggle general editable for save/cancel buttons
      oFM.setProperty("/editable", bEditable);

      // Enable only the relevant date section
      oFM.setProperty("/parentEditable", bIsParent ? bEditable : false);
      oFM.setProperty("/childEditable", !bIsParent ? bEditable : false);
    },




    // =============================================Save=====================================================================================================================
    onSave: function () {
      // Get models from the view
      var oFM = this.getView().getModel("formGeneral");     // UI state model (editability flags)
      var oBM = this.getView().getModel("branchModel");     // Data model for branch details
      var oCompModel = this.getOwnerComponent().getModel("oJsonGOModel"); // Component-level model (used for saving locally)

      // Extract data from the branch model
      var sBranchCode = oBM.getProperty("/BranchCode");
      var sBranchName = oBM.getProperty("/branchName");
      var sDesc = oBM.getProperty("/Description");
      var sValidFrom = oBM.getProperty("/ValidFrom");
      var sValidTo = oBM.getProperty("/ValidTo");

      // Check editability flags
      var bIsParentEditable = oFM.getProperty("/parentEditable");
      var bIsChildEditable = oFM.getProperty("/childEditable");

      // === Validation: Mandatory fields ===
      if (bIsChildEditable) {
        if (!sDesc || !sBranchCode) {
          MessageBox.error(this.getView().getModel("i18n").getProperty("errorMandatoryFields"), {
            title: "Error"
          });
          return;
        }
      }

      // === Validation: Branch Code format ===
      if (bIsChildEditable) {
        var regex = /^[a-zA-Z0-9]{12}$/;
        if (!regex.test(sBranchCode)) {
          MessageBox.error(this.getView().getModel("i18n").getProperty("errorInvalidBranchCode"), {
            title: "Error"
          });
          return;
        }

        // === Validation: Valid From date should not be in the past ===
        var oValidFromDate = new Date(sValidFrom);
        var oToday = new Date();
        oToday.setHours(0, 0, 0, 0); // reset to midnight

        if (oValidFromDate < oToday) {
          MessageBox.error(this.getView().getModel("i18n").getProperty("errorPastValidFrom"), {
            title: "Error"
          });
          return;
        }

        // === Validation: Valid To date must be in the future ===
        var oValidToDate = new Date(sValidTo);
        if (oValidToDate <= oToday) {
          MessageBox.error(this.getView().getModel("i18n").getProperty("errorInvalidValidTo"), {
            title: "Error"
          });
          return;
        }

        // === Validation: Valid From and Valid To should not be the same ===
        if (oValidFromDate.getTime() === oValidToDate.getTime()) {
          MessageBox.error(this.getView().getModel("i18n").getProperty("errorSameDates"), {
            title: "Error"
          });
          return;
        }
      }

      // === Save Data ===
      // If using local JSON model (current implementation)
      oCompModel.setProperty(this._sBranchPath + "/BranchCode", sBranchCode);
      oCompModel.setProperty(this._sBranchPath + "/ObjectName", sBranchName);
      oCompModel.setProperty(this._sBranchPath + "/Description", sDesc);
      oCompModel.setProperty(this._sBranchPath + "/ValidFrom", sValidFrom);
      oCompModel.setProperty(this._sBranchPath + "/ValidTo", sValidTo);

      // Save to localStorage (temporary persistence)
      localStorage.setItem("savedTreeData", JSON.stringify(oCompModel.getData()));

      // Show success message
      MessageToast.show(this.getView().getModel("i18n").getProperty("successBranchSaved"));

      // Reset editability flags
      oFM.setProperty("/parentEditable", false);
      oFM.setProperty("/childEditable", false);

      // === If using OData service instead ===
      // You would replace the above saving logic with something like:
      /*
      var oODataModel = this.getView().getModel(); // assuming default OData model
      var oPayload = {
        BranchCode: sBranchCode,
        ObjectName: sBranchName,
        Description: sDesc,
        ValidFrom: sValidFrom,
        ValidTo: sValidTo
      };
    
      oODataModel.update("/BranchSet('" + sBranchCode + "')", oPayload, {
        success: function() {
          MessageToast.show("Branch updated successfully");
        },
        error: function(oError) {
          MessageBox.error("Failed to update branch");
        }
      });
      */
    },

    // =====================================max,min,close==========================================================================
    fnOnMaximize: function () {
      var oFCL = this.getView().getParent().getParent();
      oFCL.setLayout(LayoutType.MidColumnFullScreen);
    },

    fnOnMinimize: function () {
      var oFCL = this.getView().getParent().getParent();
      // restore to two-columns (mid expanded)
      oFCL.setLayout(LayoutType.TwoColumnsMidExpanded);
    },

    fnOnClose: function () {
      var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
      oRouter.navTo("Home", { layout: "OneColumn" });
    },


    // ========================================Delete========================================================================================
    onDelete: function () {
      // Get the component-level JSON model (used for storing the tree structure)
      var oCompModel = this.getOwnerComponent().getModel("oJsonGOModel");
      var oData = oCompModel.getData(); // Full data tree
      var sPath = this._sBranchPath;    // Path to the selected branch node
      var oNode = oCompModel.getProperty(sPath); // Node to be deleted

      // Recursive function to find and remove the node from the tree
      function removeNode(aNodes, oTarget) {
        for (let i = 0; i < aNodes.length; i++) {
          if (aNodes[i] === oTarget) {
            aNodes.splice(i, 1); // Remove the node
            return true;
          }
          if (aNodes[i].children) {
            if (removeNode(aNodes[i].children, oTarget)) {
              return true;
            }
          }
        }
        return false;
      }

      // Attempt to delete the node from the tree
      var bDeleted = removeNode(oData.nodeRoot || [], oNode);

      if (bDeleted) {
        // Update the model and persist to localStorage
        oCompModel.setData(oData);
        localStorage.setItem("savedTreeData", JSON.stringify(oData));

        // Show success message
        sap.m.MessageToast.show(this.getView().getModel("i18n").getProperty("successBranchDeleted"));

        // Clear the branch model to reset the form
        this.getView().setModel(new JSONModel({}), "branchModel");

        // Reset form state flags
        this.getView().getModel("formGeneral").setData({
          editable: false,
          parentEditable: false,
          childEditable: false,
          isParent: false
        });

        // Disable Edit/Delete buttons
        this.byId("btnEditGeneral").setEnabled(false);
        this.byId("btnDelete").setEnabled(false);

        // Clear the internal path reference
        this._sBranchPath = null;

      } else {
        // Show error if deletion failed
        sap.m.MessageToast.show(this.getView().getModel("i18n").getProperty("errorDeleteFailed"));
      }

      // === If using OData service instead ===
      // Replace the above logic with an OData delete call like this:
      /*
      var oODataModel = this.getView().getModel(); // Assuming default OData model
      var sBranchKey = oNode.BranchCode; // or another unique key
    
      oODataModel.remove("/BranchSet('" + sBranchKey + "')", {
        success: function () {
          MessageToast.show("Branch deleted successfully");
    
          // Reset UI state as above
          this.getView().setModel(new JSONModel({}), "branchModel");
          this.getView().getModel("formGeneral").setData({
            editable: false,
            parentEditable: false,
            childEditable: false,
            isParent: false
          });
          this.byId("btnEditGeneral").setEnabled(false);
          this.byId("btnDelete").setEnabled(false);
          this._sBranchPath = null;
        }.bind(this),
        error: function () {
          MessageBox.error("Failed to delete branch");
        }
      });
      */
    },

    // =========================================Cancel=======================================
    onCancel: function () {
      var oBM = this.getView().getModel("branchModel");
      var oFM = this.getView().getModel("formGeneral");

      // 1. Grab the current branchName so we don’t lose it
      var sBranchName = oBM.getProperty("/branchName");

      // 2. Clear the other editable fields
      oBM.setProperty("/BranchCode", "");
      oBM.setProperty("/Description", "");

      // 3. Make sure branchName stays put
      oBM.setProperty("/branchName", sBranchName);

      // 4. Turn off edit mode
      // oFM.setProperty("/editable", false);
      oFM.setProperty("/parentEditable", false);
      oFM.setProperty("/childEditable", false);

      MessageToast.show(this.getView().getModel("i18n").getProperty("infoChangesDiscarded"));
    }
    // =============================================================================================

  });
});
