
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "project1/model/GeneralData",
    "project1/model/FinanceData",
    "project1/model/HRData",
    "project1/model/formatter"


], (Controller, JSONModel, MessageToast, GeneralData, FinanceData, HRData, formatter) => {
    "use strict";

    return Controller.extend("project1.controller.Home", {
        formatter: formatter,
        onInit() {
            this._oSelectedBranch = null;
            this._oMoveTargetBranch = null;
            this._allowedTopName = null;
            this.oRouter = this.getOwnerComponent().getRouter();
            this.fnloadTreeData("learning");            //  Replace with OData call to fetch 'learning' hierarchy
        },

        // onAfterRendering: function () {
        //     var oNextUIState = this.getOwnerComponent().getHelper().getNextUIState(1);
        //     this.oRouter.navTo("Details", { branch: "0", layout: oNextUIState.layout });
        // },


        // ==================================SegmentedButton for hierarchy type switching=======================

        // Extracted helper to load any tree
        fnloadTreeData: function (sKey) {
            let oData;
            switch (sKey) {
                case "learning":
                    oData = GeneralData.getData();    //  Replace with OData call to fetch learning data
                    break;
                case "finance":
                    oData = FinanceData.getData();      
                    break;
                case "hr":
                    oData = HRData.getData();          
                    break;
            }

            var oTreeModel = new JSONModel(oData);      //  Replace with ODataModel binding if using OData


            // always set on both view AND component
            this.getView().setModel(oTreeModel, "oJsonGOModel");            //  With OData, bind the ODataModel here
            this.getOwnerComponent().setModel(oTreeModel, "oJsonGOModel");   // With OData, set the ODataModel instead

        },

        onHierarchySelectionChange(oEvent) {
            var sKey = oEvent.getParameter("item").getKey();

            this.fnloadTreeData(sKey);

            var oNextUIState = this.getOwnerComponent().getHelper().getNextUIState(1);
            this.oRouter.navTo("Details", {
                branch: "0",
                layout: oNextUIState.layout

            });
        },

        // In an OData implementation, replace these with OData model read calls to fetch data from the backend:
        // Example:
        //   var oODataModel = this.getView().getModel(); // Assuming default OData model
        //   oODataModel.read("/BranchSet", {
        //     filters: [new Filter("Category", FilterOperator.EQ, sKey)],
        //     success: function (oData) {
        //       var oTreeModel = new JSONModel(oData.results); // or bind directly to ODataModel
        //       this.getView().setModel(oTreeModel, "oJsonGOModel");
        //       this.getOwnerComponent().setModel(oTreeModel, "oJsonGOModel");
        //     }.bind(this),
        //     error: function () {
        //       MessageBox.error("Failed to load tree data for " + sKey);
        //     }
        // });




        // =======================================================Navigation====================================================================================


        fnOnSelectionChange: function (oEvent) {
            // Get the selected item from the tree event
            var oItem = oEvent.getParameter("listItem");
            if (!oItem) {
                this._oSelectedBranch = null;
                return;
            }

            // Get the component-level JSON model (used for storing the tree structure)
            var oModel = this.getView().getModel("oJsonGOModel");
            var oCtx = oItem.getBindingContext("oJsonGOModel");
            var sPath = oCtx.getPath(); // e.g. "/nodeRoot/children/0/children/2"
            var oSel = oCtx.getObject(); // Selected node object

            // Derive the parent path by trimming the last "/children" segment
            var sParentPath = sPath.substring(0, sPath.lastIndexOf("/children"));
            var oParent = oModel.getProperty(sParentPath) || {};

            // Recursively select all child nodes in the UI (if applicable)
            if (this._selectAllChildrenUI) {
                this._selectAllChildrenUI(this.byId("HierarchyTree"), oItem);
            }

            // Store the selected branch internally
            this._oSelectedBranch = oSel;

            // Determine if the selected node is a parent (has children)

            var sParentPath = sPath.substring(0, sPath.lastIndexOf("/children"));
            var isTopLevel = sParentPath === "";

            // Build the payload to pass to the next view
            var oPayload = {
                path: sPath,
                // parentName: oParent.ObjectName || "Top Level Branch",
                parentName: isTopLevel ? oSel.ObjectName : (oParent.ObjectName || ""), //if parent selected then in parent branch name parent branch name will show
                branchName: isTopLevel ? "" : oSel.ObjectName,                      // if parent is selected then in chiled section name will not visible
                BranchCode: oSel.BranchCode,
                LogonLanguage: oSel.LogonLanguage,
                Description: oSel.Description,
                ValidFrom: oSel.validFrom,
                ValidTo: oSel.validTo,
                isParent: oSel.children && oSel.children.length > 0
            };

            // Navigate to Details with the payload
            var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            oRouter.navTo("Details", {
                branch: encodeURIComponent(JSON.stringify(oPayload)),
                layout: "TwoColumnsMidExpanded"
            });

            // === If using OData service instead ===
            // Replace the above logic with OData binding and navigation like this:
            /*
            var oODataModel = this.getView().getModel(); // Assuming default OData model
            var oCtx = oItem.getBindingContext(); // OData context
            var sPath = oCtx.getPath(); // e.g. "/BranchSet('BR001')"
            var oSel = oCtx.getObject(); // Selected entity
          
            var oPayload = {
              path: sPath,
              BranchCode: oSel.BranchCode,
              branchName: oSel.ObjectName
              // You can fetch additional details in Details using this path or BranchCode
            };
          
            var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            oRouter.navTo("Details", {
              branch: encodeURIComponent(JSON.stringify(oPayload)),
              layout: "TwoColumnsMidExpanded"
            });
            */
        },




        // ==================================================Expand Collaps============================================================================
        fnOnToggleExpandCollapse: function () {
            var oTree = this.byId("HierarchyTree");
            var oButton = this.byId("btnToggleExpandCollapse");

            // Initialize state if not already set
            if (this._bTreeExpanded === undefined) {
                this._bTreeExpanded = false;
            }

            if (!this._bTreeExpanded) {
                // Expand all
                oTree.expandToLevel(999);
                oButton.setIcon("sap-icon://collapse-all");
                oButton.setTooltip("Collapse All");
                this._bTreeExpanded = true;
            } else {
                // Collapse all
                oTree.collapseAll();
                oButton.setIcon("sap-icon://expand-all");
                oButton.setTooltip("Expand All");
                this._bTreeExpanded = false;
            }
        },




        // ==================================================Search ========================================================================================



        fnSearchBranchAdmin: function (oEvent) {
            var sQuery = oEvent.getParameter("query");
            var oTree = this.byId("HierarchyTree");
            var oBinding = oTree.getBinding("items");

            if (sQuery) {
                // [OData] This filter applies to the 'ObjectName' property in the bound model.
                // If using an ODataModel, this generates a $filter query option like:
                // ?$filter=contains(ObjectName, 'searchText')
                // Make sure the backend OData service supports $filter on 'ObjectName'

                var oFilter = new sap.ui.model.Filter(
                    "ObjectName",
                    sap.ui.model.FilterOperator.Contains,
                    sQuery
                );

                oBinding.filter([oFilter]);
            } else {
                // [OData] Clears any existing $filter from the OData request
                oBinding.filter([]);
            }
        },



        // =========================================================== Menu==========================================================================================
        fnOnPressMenu: function (oEvent) {
            var oButton = oEvent.getSource();

            if (!this._oPopover) {
                this._oPopover = sap.ui.xmlfragment("project1.fragments.Menu", this);
                this.getView().addDependent(this._oPopover);
            }

            this._oPopover.openBy(oButton);
        },






        // =================================================================Create==================================================================================
        // Open the create branch dialog.
        fnOnCreateBranch: function () {
            var oView = this.getView();
            if (!this._oCreateBranchDialog) {
                this._oCreateBranchDialog = sap.ui.xmlfragment("project1.fragments.CreateBranch", this);
                oView.addDependent(this._oCreateBranchDialog);
            }
            this._oCreateBranchDialog.open();
        },

        fnOnConfirmBranch: function () {
            var oTree = this.getView().byId("HierarchyTree");
            var oJsonModel = this.getView().getModel("oJsonGOModel"); // Replace this with OData model
            var oData = oJsonModel.getData(); // No need for this when using OData create

            var sBranchName = sap.ui.getCore().byId("branchNameInput").getValue();
            if (!sBranchName) {
                MessageToast.show(this.getView().getModel("i18n").getProperty("enterValidBranchName"));
                return;
            }

            var oNewBranch = {
                "ObjectName": sBranchName,
                "children": [] // In OData, create payload and call oModel.create("/EntitySet", payload)
            };

            if (this._oSelectedBranch) {
                if (!this._oSelectedBranch.children) {
                    this._oSelectedBranch.children = [];
                }
                this._oSelectedBranch.children.push(oNewBranch); // Replace with backend logic to set parent-child link in OData
            } else {
                oData.nodeRoot.push(oNewBranch); // Replace this with root-level create call to OData backend
            }

            localStorage.setItem("savedTreeData", JSON.stringify(oData)); // Not required in OData implementation
            oJsonModel.setData(oData); // Not required in OData implementation
            oTree.getBinding("items").refresh(); // Use oModel.refresh() or rebind instead in OData

            sap.ui.getCore().byId("branchNameInput").setValue("");
            this._oCreateBranchDialog.close();
            MessageToast.show(this.getView().getModel("i18n").getProperty("CreateBranchName"));
        },

        // === If using OData service instead ===
        // Replace the above logic with an OData create call like this:
        /*
        var oODataModel = this.getView().getModel(); // Assuming default OData model
        var oPayload = {
          ObjectName: sBranchName,
          ParentBranchCode: this._oSelectedBranch ? this._oSelectedBranch.BranchCode : null
        };
       
        oODataModel.create("/BranchSet", oPayload, {
          success: function () {
            MessageToast.show("Branch created successfully");
            this._oCreateBranchDialog.close();
            sap.ui.getCore().byId("branchNameInput").setValue("");
            oODataModel.refresh(); // Refresh the model to update the tree
          }.bind(this),
          error: function () {
            MessageBox.error("Failed to create branch");
          }
        });
        */
        fnOnCancelBranch: function () {
            this._oCreateBranchDialog.close();
        },





        //===================================================== Delete =======================================================================


        fnOnDeleteBranch: function () {
            if (!this._oSelectedBranch) {
                MessageToast.show(this.getView().getModel("i18n").getProperty("selectBranchToDelete"));
                return;
            }

            var oJsonModel = this.getView().getModel("oJsonGOModel");
            var oData = oJsonModel.getData();

            function removeNode(aNodes, oNodeToRemove) {
                for (var i = 0; i < aNodes.length; i++) {
                    if (aNodes[i] === oNodeToRemove) {
                        aNodes.splice(i, 1);
                        return true;
                    } else if (aNodes[i].children && aNodes[i].children.length > 0) {
                        var bRemoved = removeNode(aNodes[i].children, oNodeToRemove);
                        if (bRemoved) return true;
                    }
                }
                return false;
            }

            var bDeleted = removeNode(oData.nodeRoot, this._oSelectedBranch);
            if (bDeleted) {
                localStorage.setItem("savedTreeData", JSON.stringify(oData));
                oJsonModel.setData(oData);
                this.getView().byId("HierarchyTree").getBinding("items").refresh();
                MessageToast.show(this.getView().getModel("i18n").getProperty("branchDeleted"));

                if (this._oMenuFragment) {
                    var oDeleteMenuItem = sap.ui.core.Fragment.byId(this._oMenuFragment.getId(), "_IDGenMenuItem2");
                    if (oDeleteMenuItem) oDeleteMenuItem.setEnabled(false);
                }
            } else {
                MessageToast.show(this.getView().getModel("i18n").getProperty("branchDeleteFailed"));
            }
        },
        // === If using OData service instead ===
        // Replace the above logic with an OData delete call like this:
        /*
        var oODataModel = this.getView().getModel(); // Assuming default OData model
        var sBranchKey = oNode.BranchCode; // or another unique key
      
        oODataModel.remove("/BranchSet('" + sBranchKey + "')", {
          success: function () {
            MessageToast.show("Branch deleted successfully");
      
            // Reset UI state as above
            this.getView().setModel(new JSONModel({}), "branchModel");
            this.getView().getModel("formGeneral").setData({
              editable: false,
              parentEditable: false,
              childEditable: false,
              isParent: false
            });
            this.byId("btnEditGeneral").setEnabled(false);
            this.byId("btnDelete").setEnabled(false);
            this._sBranchPath = null;
          }.bind(this),
          error: function () {
            MessageBox.error("Failed to delete branch");
          }
        });
        */





        // =================================================  Edit  =================================================================================================

        fnOnEditBranch: function () {
            var oView = this.getView();

            // Ensure the dialog is created only once
            if (!this._oEditBranchDialog) {
                this._oEditBranchDialog = sap.ui.xmlfragment("project1.fragments.EditBranch", this);
                oView.addDependent(this._oEditBranchDialog);
            }

            // Fetch the latest branch name from the JSON model
            var oJsonModel = this.getView().getModel("oJsonGOModel");
            var oUpdatedBranch = oJsonModel.getProperty(this._oSelectedBranch.__path); // In OData, use binding context or key

            // Reset the input field before opening the dialog
            var oInput = sap.ui.getCore().byId("editBranchNameInput");
            if (oUpdatedBranch) {
                oInput.setValue(oUpdatedBranch.ObjectName);
            } else {
                oInput.setValue(""); // Clear if data is not found
            }

            this._oEditBranchDialog.open();

            // === If using OData service instead ===
            // You can bind the input field directly to the OData model or fetch the entity by key
            /*
            var oODataModel = this.getView().getModel();
            var sPath = this._oSelectedBranch.__path; // e.g. "/BranchSet('BR001')"
            oODataModel.read(sPath, {
              success: function (oData) {
                sap.ui.getCore().byId("editBranchNameInput").setValue(oData.ObjectName);
                this._oEditBranchDialog.open();
              }.bind(this),
              error: function () {
                MessageBox.error("Failed to load branch details");
              }
            });
            */
        },

        fnOnConfirmEditBranch: function () {
            var sNewBranchName = sap.ui.getCore().byId("editBranchNameInput").getValue();

            if (!sNewBranchName) {
                MessageToast.show(this.getView().getModel("i18n").getProperty("enterName"));
                return;
            }

            // Update the selected branch's name in the JSON model
            this._oSelectedBranch.ObjectName = sNewBranchName;

            // Refresh the model and tree binding
            var oJsonModel = this.getView().getModel("oJsonGOModel");
            oJsonModel.updateBindings();

            // Save the updated data in local storage
            var oData = oJsonModel.getData();
            localStorage.setItem("savedTreeData", JSON.stringify(oData)); // Not required in OData implementation

            this._oEditBranchDialog.close();
            MessageToast.show(this.getView().getModel("i18n").getProperty("updateBranch"));
            this.fnClearSelection();

            // === If using OData service instead ===
            // Replace the above logic with an OData update call like this:
            /*
            var oODataModel = this.getView().getModel();
            var sPath = this._oSelectedBranch.__path; // e.g. "/BranchSet('BR001')"
            var oPayload = {
              ObjectName: sNewBranchName
            };
          
            oODataModel.update(sPath, oPayload, {
              success: function () {
                MessageToast.show("Branch updated successfully");
                this._oEditBranchDialog.close();
                this.fnClearSelection();
                oODataModel.refresh(); // Refresh the model to reflect changes
              }.bind(this),
              error: function () {
                MessageBox.error("Failed to update branch");
              }
            });
            */
        },

        fnOnCancelEditBranch: function () {
            // Close the edit dialog without saving changes
            this._oEditBranchDialog.close();
        },








        // ===================================================Move=================================================================================================

        fnOnMoveBranch: function () {
            if (!this._oSelectedBranch) {
                MessageToast.show(this.getView().getModel("i18n").getProperty("MoveConBranch"));
                return;
            }

            var oView = this.getView();
            var oJsonModel = this.getView().getModel("oJsonGOModel");
            var oData = oJsonModel.getData();

            if (oData.nodeRoot.indexOf(this._oSelectedBranch) !== -1) {
                MessageToast.show(this.getView().getModel("i18n").getProperty("MainBranchMove"));
                return;
            }

            var oAllowedTop = this._findAllowedTop(oData.nodeRoot, this._oSelectedBranch);
            if (!oAllowedTop) {
                MessageToast.show(this.getView().getModel("i18n").getProperty("moveDestination"));
                return;
            }
            this._allowedTopName = oAllowedTop.ObjectName;

            this._updateActionOnNodes(oData.nodeRoot, this._allowedTopName);
            oJsonModel.refresh();

            if (!this._oMoveBranchDialog) {
                this._oMoveBranchDialog = sap.ui.xmlfragment("project1.fragments.MoveDialog", this);
                this.getView().addDependent(this._oMoveBranchDialog);
            }

            // Reset selection for radio buttons before opening the dialog
            var oRadioGroup = sap.ui.getCore().byId("moveBranchRadioGroup"); // 
            if (oRadioGroup) {
                oRadioGroup.setSelectedIndex(-1); // Clear selection
            }

            this._oMoveTargetBranch = null;
            this._oMoveBranchDialog.open();



            // === If using OData service instead ===
            // You would fetch valid move targets from backend and bind them to the dialog
            /*
            var oODataModel = this.getView().getModel();
            oODataModel.read("/BranchSet", {
              success: function (oData) {
                // Filter and bind valid move targets to the dialog
                this._oMoveBranchDialog.open();
              }.bind(this),
              error: function () {
                MessageBox.error("Failed to load move targets");
              }
            });
            */

        },

        // --- Helper functions to get allowed top branch and update model flags ---

        _findAllowedTop: function (aNodes, oSelectedBranch) {
            var oAllowed = null;
            aNodes.some(function (node) {
                if (this._searchBranch(node, oSelectedBranch)) {
                    oAllowed = node;
                    return true;
                }
                return false;
            }.bind(this));
            return oAllowed;
        },

        _searchBranch: function (oNode, oSelectedBranch) {
            if (oNode === oSelectedBranch) {
                return true;
            }
            if (oNode.children) {
                return oNode.children.some(function (child) {
                    return this._searchBranch(child, oSelectedBranch);
                }.bind(this));
            }
            return false;
        },

        _updateActionOnNodes: function (aNodes, sAllowedTopName) {
            aNodes.forEach(function (node) {
                // Disable the selected branch from appearing as a valid move target
                node.action = node.ObjectName !== this._oSelectedBranch.ObjectName;

                // Enable only the allowed top branch
                if (node.ObjectName === sAllowedTopName) {
                    node.action = true;
                    if (node.children) {
                        this._setActionRecursively(node.children, true, this._oSelectedBranch);
                    }
                } else {
                    node.action = false;
                    if (node.children) {
                        this._setActionRecursively(node.children, false, this._oSelectedBranch);
                    }
                }
            }.bind(this));
        },

        _setActionRecursively: function (aNodes, bAllowed, oSelectedBranch) {
            aNodes.forEach(function (child) {
                // Ensure selected branch is disabled
                child.action = bAllowed && child.ObjectName !== oSelectedBranch.ObjectName;
                if (child.children) {
                    this._setActionRecursively(child.children, bAllowed, oSelectedBranch);
                }
            }.bind(this));
        },


        // --- Handling the move dialog selection ---

        onMoveBranchSelect: function (oEvent) {
            var oSelectedItem = oEvent.getParameter("listItem");
            if (oSelectedItem) {
                this._oMoveTargetBranch = oSelectedItem.getBindingContext("oJsonGOModel").getObject();
                // MessageToast.show("Selected destination: " + this._oMoveTargetBranch.ObjectName);
            }
        },

        // (Alternatively, you can also use the radio button’s event.)
        fnSelectRadioMove: function (oEvent) {
            var oRadioButton = oEvent.getSource();
            var oFlexBox = oRadioButton.getParent();
            var oContext = oFlexBox.getBindingContext("oJsonGOModel");
            if (oContext) {
                this._oMoveTargetBranch = oContext.getObject();
            }
        },

        // --- Confirm and process the move ---

        fnMoveConfirm: function () {
            if (!this._oMoveTargetBranch) {
                // MessageToast.show("Please select a destination branch in the move dialog.");
                MessageToast.show(this.getView().getModel("i18n").getProperty("Movedestination"));

                return;
            }
            if (!this._oSelectedBranch) {
                // MessageToast.show("No branch was selected in the main view to move.");
                MessageToast.show(this.getView().getModel("i18n").getProperty("mainBranchMove"));
                return;
            }

            // Get the JSON model and its data.
            var oJsonModel = this.getView().getModel("oJsonGOModel");
            var oData = oJsonModel.getData();

            // Remove the selected branch from its current location…
            var oBranchToMove = this._oSelectedBranch;
            var bRemoved = this._removeBranch(oData.nodeRoot, oBranchToMove);
            if (bRemoved) {
                // …then append it under the destination branch.
                if (!this._oMoveTargetBranch.children) {
                    this._oMoveTargetBranch.children = [];
                }
                this._oMoveTargetBranch.children.push(oBranchToMove);
                oJsonModel.setData(oData);
                // MessageToast.show("Successfully moved branch to: " + this._oMoveTargetBranch.ObjectName);
                MessageToast.show(this.getView().getModel("i18n").getProperty("MoveSuccess"));
            } else {
                // MessageToast.show("Failed to move the branch.");
                MessageToast.show(this.getView().getModel("i18n").getProperty("MoveFailed"));
            }

            // Close the dialog and clear the selections.
            this._oMoveBranchDialog.close();
            this._oSelectedBranch = null;
            this._oMoveTargetBranch = null;
            this.fnClearSelection();
            // === If using OData service instead ===
            // Replace the above logic with an OData update call like this:
            /*
            var oODataModel = this.getView().getModel();
            var oPayload = {
              BranchCode: this._oSelectedBranch.BranchCode,
              NewParentCode: this._oMoveTargetBranch.BranchCode
            };
           
            oODataModel.callFunction("/MoveBranch", {
              method: "POST",
              urlParameters: oPayload,
              success: function () {
                MessageToast.show("Branch moved successfully");
                this._oMoveBranchDialog.close();
                this.fnClearSelection();
                oODataModel.refresh(); // Refresh to reflect changes
              }.bind(this),
              error: function () {
                MessageBox.error("Failed to move branch");
              }
            });
            */
        },

        // Recursive helper to remove a branch from the hierarchy.
        _removeBranch: function (aBranches, oBranchToRemove) {
            for (var i = 0; i < aBranches.length; i++) {
                if (aBranches[i] === oBranchToRemove) {
                    aBranches.splice(i, 1);
                    return true;
                }
                if (aBranches[i].children) {
                    var bRemoved = this._removeBranch(aBranches[i].children, oBranchToRemove);
                    if (bRemoved) {
                        return true;
                    }
                }
            }
            return false;
        },

        // --- Cancel Move Operation ---
        fnOnMoveCancel: function () {
            if (this._oMoveBranchDialog) {
                this._oMoveBranchDialog.close();
            }
            this._oMoveTargetBranch = null;
        }
    });
});
