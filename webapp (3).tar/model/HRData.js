sap.ui.define([], function () {
    "use strict";
    
    return {
        getData: function () {
            return {
                "nodeRoot": [
                    {
                        "ObjectName": "Recruitment",
                        "validFrom": "2023-01-01",
                        "validTo": "2025-12-31",
                        "children": [
                            {
                                "ObjectName": "Recruitment Manager",
                                "validFrom": "2023-01-01",
                                "validTo": "2025-01-01",
                                "children": [
                                    { "ObjectName": "Manage Job Postings", "validFrom": "2023-01-01", "validTo": "2024-12-31" },
                                    { "ObjectName": "Review Applications", "validFrom": "2023-02-01", "validTo": "2025-01-01" },
                                    { "ObjectName": "Schedule Interviews", "validFrom": "2023-03-01", "validTo": "2025-12-31" }
                                ]
                            },
                            {
                                "ObjectName": "Hiring Specialist",
                                "validFrom": "2023-06-01",
                                "validTo": "2025-12-31",
                                "children": [
                                    { "ObjectName": "Initiate Offer Letters", "validFrom": "2023-06-01", "validTo": "2025-06-01" },
                                    { "ObjectName": "Track Onboarding Status", "validFrom": "2023-07-01", "validTo": "2025-12-31" }
                                ]
                            }
                        ]
                    },
                    {
                        "ObjectName": "Employee Services",
                        "validFrom": "2022-01-01",
                        "validTo": "2026-01-01",
                        "children": [
                            {
                                "ObjectName": "HR Services Representative",
                                "validFrom": "2022-01-01",
                                "validTo": "2025-12-31",
                                "children": [
                                    { "ObjectName": "Manage Employee Records", "validFrom": "2022-01-01", "validTo": "2024-12-31" },
                                    { "ObjectName": "Update Personal Details", "validFrom": "2022-05-01", "validTo": "2026-01-01" },
                                    { "ObjectName": "Handle Employee Inquiries", "validFrom": "2022-06-01", "validTo": "2025-06-30" }
                                ]
                            },
                            {
                                "ObjectName": "Payroll Coordinator",
                                "validFrom": "2023-01-01",
                                "validTo": "2026-01-01",
                                "children": [
                                    { "ObjectName": "Manage Payroll Schedule", "validFrom": "2023-01-01", "validTo": "2024-12-31" },
                                    { "ObjectName": "Update Bank Details", "validFrom": "2023-02-01", "validTo": "2026-01-01" },
                                    { "ObjectName": "Process Salary Adjustments", "validFrom": "2023-03-01", "validTo": "2025-12-31" }
                                ]
                            }
                        ]
                    },
                    {
                        "ObjectName": "Performance Management",
                        "validFrom": "2023-04-01",
                        "validTo": "2026-12-31",
                        "children": [
                            {
                                "ObjectName": "HR Business Partner",
                                "validFrom": "2023-04-01",
                                "validTo": "2026-12-31",
                                "children": [
                                    { "ObjectName": "Set Performance Goals", "validFrom": "2023-04-01", "validTo": "2025-01-01" },
                                    { "ObjectName": "Initiate Reviews", "validFrom": "2023-05-01", "validTo": "2026-01-01" },
                                    { "ObjectName": "Monitor Feedback", "validFrom": "2023-06-01", "validTo": "2026-12-31" }
                                ]
                            },
                            {
                                "ObjectName": "Training Coordinator",
                                "validFrom": "2023-07-01",
                                "validTo": "2025-12-31",
                                "children": [
                                    { "ObjectName": "Assign Training Courses", "validFrom": "2023-07-01", "validTo": "2024-12-31" },
                                    { "ObjectName": "Track Training Completion", "validFrom": "2023-08-01", "validTo": "2025-12-31" },
                                    { "ObjectName": "Evaluate Training Effectiveness", "validFrom": "2023-09-01", "validTo": "2026-12-31" }
                                ]
                            }
                        ]
                    }
                ]
            };
        }
    };
});
