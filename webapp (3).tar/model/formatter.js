sap.ui.define([], function () {
    "use strict";
    return {
        isExpired: function (validTo) {
            if (!validTo) return false;
            const today = new Date();
            const validToDate = new Date(validTo);
            return validToDate < today;
        }
    };
});
