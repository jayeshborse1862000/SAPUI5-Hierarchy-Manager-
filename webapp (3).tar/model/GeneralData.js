sap.ui.define([], function () {
    "use strict";

    return {
        getData: function () {
            return {
                "nodeRoot": [
                    {
                        "ObjectName": "Machine Learning",
                        "validFrom": "2022-01-01",
                        "validTo": "2025-12-31",
                        "children": [
                            {
                                "ObjectName": "Basics",
                                "validFrom": "2022-01-01",
                                "validTo": "2024-06-01",
                                "children": [
                                    { "ObjectName": "Supervised Learning", "validFrom": "2022-01-01", "validTo": "2023-12-31" },
                                    { "ObjectName": "Unsupervised Learning", "validFrom": "2023-01-01", "validTo": "2024-06-01" },
                                    { "ObjectName": "Reinforcement Learning", "validFrom": "2024-02-01", "validTo": "2024-06-01" }
                                ]
                            },
                            {
                                "ObjectName": "Advanced Topics",
                                "validFrom": "2023-05-01",
                                "validTo": "2025-12-31",
                                "children": [
                                    { "ObjectName": "Deep Learning", "validFrom": "2023-05-01", "validTo": "2024-12-31" },
                                    { "ObjectName": "Ensemble Methods", "validFrom": "2025-01-01", "validTo": "2025-12-31" },
                                    { "ObjectName": "Model Interpretability", "validFrom": "2023-05-01", "validTo": "2024-12-31" }
                                ]
                            }
                        ]
                    },
                    {
                        "ObjectName": "SAP Fiori",
                        "validFrom": "2023-07-01",
                        "validTo": "2026-06-30",
                        "children": [
                            {
                                "ObjectName": "Fundamentals",
                                "validFrom": "2023-07-01",
                                "validTo": "2025-08-31",
                                "children": [
                                    { "ObjectName": "UX Design Principles", "validFrom": "2024-01-01", "validTo": "2025-08-31" },
                                    { "ObjectName": "Fiori Launchpad Basics", "validFrom": "2023-07-01", "validTo": "2023-07-01" },
                                    { "ObjectName": "SAPUI5 Overview", "validFrom": "2023-10-01", "validTo": "2025-08-31" }
                                ]
                            },
                            {
                                "ObjectName": "Advanced Development",
                                "validFrom": "2023-07-01",
                                "validTo": "2026-06-30",
                                "children": [
                                    { "ObjectName": "Fiori Elements", "validFrom": "2023-07-01", "validTo": "2024-05-01" },
                                    { "ObjectName": "Smart Controls", "validFrom": "2023-11-01", "validTo": "2026-06-30" },
                                    { "ObjectName": "Spaces & Pages", "validFrom": "2023-07-01", "validTo": "2024-12-31" }
                                ]
                            }
                        ]
                    },
                    {
                        "ObjectName": "RAP (Restful ABAP Programming)",
                        "validFrom": "2024-01-01",
                        "validTo": "2027-01-01",
                        "children": [
                            {
                                "ObjectName": "Core Concepts",
                                "validFrom": "2024-01-01",
                                "validTo": "2024-12-31",
                                "children": [
                                    { "ObjectName": "CDS Views", "validFrom": "2024-01-01", "validTo": "2024-12-31" },
                                    { "ObjectName": "Behavior Definition", "validFrom": "2024-01-01", "validTo": "2024-12-31" },
                                    { "ObjectName": "Service Definition", "validFrom": "2024-01-01", "validTo": "2024-12-31" }
                                ]
                            },
                            {
                                "ObjectName": "Advanced RAP",
                                "validFrom": "2024-01-01",
                                "validTo": "2027-01-01",
                                "children": [
                                    { "ObjectName": "Draft Handling", "validFrom": "2024-01-01", "validTo": "2026-01-01" },
                                    { "ObjectName": "Side Effects & Validations", "validFrom": "2024-01-01", "validTo": "2025-01-01" },
                                    { "ObjectName": "Extending RAP Services", "validFrom": "2024-06-01", "validTo": "2027-01-01" }
                                ]
                            }
                        ]
                    },
                    {
                        "ObjectName": "General Learning",
                        "validFrom": "2021-03-01",
                        "validTo": "2023-12-31",
                        "children": [
                            {
                                "ObjectName": "Soft Skills",
                                "validFrom": "2021-03-01",
                                "validTo": "2023-02-01",
                                "children": [
                                    { "ObjectName": "Effective Communication", "validFrom": "2021-03-01", "validTo": "2023-01-01" },
                                    { "ObjectName": "Time Management", "validFrom": "2022-01-01", "validTo": "2023-02-01" }
                                ]
                            },
                            {
                                "ObjectName": "Professional Development",
                                "validFrom": "2022-06-01",
                                "validTo": "2023-12-31",
                                "children": [
                                    { "ObjectName": "Presentation Skills", "validFrom": "2022-06-01", "validTo": "2023-05-01" },
                                    { "ObjectName": "Technical Writing", "validFrom": "2023-08-01", "validTo": "2023-12-31" }
                                ]
                            }
                        ]
                    }
                ]
            };
        }
    };
});
