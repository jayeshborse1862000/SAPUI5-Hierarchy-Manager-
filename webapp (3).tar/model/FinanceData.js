sap.ui.define([], function () {
    "use strict";

    return {
        getData: function () {
            return {
                "nodeRoot": [
                    {
                        "ObjectName": "Finance",
                        "ValidFrom": "2023-01-01",
                        "ValidTo": "2025-12-31",
                        "children": [
                            {
                                "ObjectName": "General Ledger Accountant",
                                "ValidFrom": "2023-01-01",
                                "ValidTo": "2024-12-31",
                                "children": [
                                    {
                                        "ObjectName": "Manage Banks - Master Data",
                                        "ValidFrom": "2023-01-01",
                                        "ValidTo": "2024-06-30"
                                    },
                                    {
                                        "ObjectName": "Map Format Data for Incoming Files from Banks",
                                        "ValidFrom": "2024-01-01",
                                        "ValidTo": "2025-06-30"
                                    },
                                    {
                                        "ObjectName": "Test Incoming Format Mappings",
                                        "ValidFrom": "2025-01-01",
                                        "ValidTo": "2025-12-31"
                                    }
                                ]
                            },
                            {
                                "ObjectName": "Accounts Receivable Accountant",
                                "ValidFrom": "2023-01-01",
                                "ValidTo": "2025-12-31",
                                "children": [
                                    {
                                        "ObjectName": "Monitor Payments",
                                        "ValidFrom": "2022-01-01",
                                        "ValidTo": "2023-12-31"
                                    },
                                    {
                                        "ObjectName": "Manage Automatic Payments",
                                        "ValidFrom": "2024-01-01",
                                        "ValidTo": "2025-12-31"
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "ObjectName": "Budget and Finance",
                        "ValidFrom": "2023-01-01",
                        "ValidTo": "2026-01-01",
                        "children": [
                            {
                                "ObjectName": "Internal Sales Representative",
                                "ValidFrom": "2023-01-01",
                                "ValidTo": "2024-12-31",
                                "children": [
                                    {
                                        "ObjectName": "Monitor Value Chains",
                                        "ValidFrom": "2023-01-01",
                                        "ValidTo": "2023-12-31"
                                    },
                                    {
                                        "ObjectName": "Monitor Payments",
                                        "ValidFrom": "2024-01-01",
                                        "ValidTo": "2024-12-31"
                                    },
                                    {
                                        "ObjectName": "Manage Automatic Payments",
                                        "ValidFrom": "2025-01-01",
                                        "ValidTo": "2026-01-01"
                                    }
                                ]
                            },
                            {
                                "ObjectName": "Billing Clerk",
                                "ValidFrom": "2023-07-01",
                                "ValidTo": "2025-12-31",
                                "children": [
                                    {
                                        "ObjectName": "Monitor Condition Contracts - Customers",
                                        "ValidFrom": "2023-07-01",
                                        "ValidTo": "2024-12-31"
                                    },
                                    {
                                        "ObjectName": "Condition Contract (Version 2)",
                                        "ValidFrom": "2025-01-01",
                                        "ValidTo": "2025-12-31"
                                    },
                                    {
                                        "ObjectName": "Manage Condition Contracts - External Commissions",
                                        "ValidFrom": "2023-01-01",
                                        "ValidTo": "2023-12-31"
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "ObjectName": "Sales",
                        "ValidFrom": "2022-01-01",
                        "ValidTo": "2025-12-31",
                        "children": [
                            {
                                "ObjectName": "Internal Sales Representative",
                                "ValidFrom": "2022-01-01",
                                "ValidTo": "2024-12-31",
                                "children": [
                                    {
                                        "ObjectName": "Invoice List",
                                        "ValidFrom": "2022-01-01",
                                        "ValidTo": "2023-12-31"
                                    },
                                    {
                                        "ObjectName": "Sales Order Fulfillment Issues (Version 2)",
                                        "ValidFrom": "2024-01-01",
                                        "ValidTo": "2024-12-31"
                                    },
                                    {
                                        "ObjectName": "Sales Contract Fulfillment Rates",
                                        "ValidFrom": "2025-01-01",
                                        "ValidTo": "2025-12-31"
                                    }
                                ]
                            },
                            {
                                "ObjectName": "Order Fulfillment Manager",
                                "ValidFrom": "2023-01-01",
                                "ValidTo": "2025-12-31",
                                "children": [
                                    {
                                        "ObjectName": "Configure Order Fulfillment Responsibilities",
                                        "ValidFrom": "2023-01-01",
                                        "ValidTo": "2024-01-01"
                                    },
                                    {
                                        "ObjectName": "Configure Alternative Control",
                                        "ValidFrom": "2024-01-01",
                                        "ValidTo": "2025-01-01"
                                    },
                                    {
                                        "ObjectName": "Configure Product Allocation",
                                        "ValidFrom": "2025-01-01",
                                        "ValidTo": "2025-12-31"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            };
        }
    };
});
