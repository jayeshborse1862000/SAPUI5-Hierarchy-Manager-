sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/json/JSONModel",
  "sap/m/MessageToast",
  "sap/f/library",
  "sap/m/MessageBox"
], function (Controller, JSONModel, MessageToast, fLibrary, MessageBox) {
  "use strict";

  // alias the enum
  const LayoutType = fLibrary.LayoutType;
  return Controller.extend("project1.controller.View2", {
    onInit() {
      // formGeneral toggles editability
      const oEditModel = new JSONModel({ editable: false });
      this.getView().setModel(oEditModel, "formGeneral");

      this.getOwnerComponent()
        .getRouter()
        .getRoute("View2")
        .attachPatternMatched(this._onObjectMatched, this);
    },


    // =======================================_onObjectMatched====================================

    _onObjectMatched(oEvent) {
      // 1. Decode the payload and stash the path
      const sPayload = oEvent.getParameter("arguments").branch;
      const oData = JSON.parse(decodeURIComponent(sPayload));
      this._sBranchPath = oData.path;

      // 2. Reset edit mode here
      this.getView()
        .getModel("formGeneral")
        .setProperty("/editable", false);

      // 3. Re-bind your form fields
      const oBranchModel = new JSONModel({
        parentName: oData.parentName,
        branchName: oData.branchName,
        BranchCode: oData.BranchCode,
        LogonLanguage: oData.LogonLanguage,
        Description: oData.Description
      });
      this.getView().setModel(oBranchModel, "branchModel");
    },


    // =====================================max,min,close=================================
    fnOnMaximize: function () {
      const oFCL = this.getView().getParent().getParent();
      oFCL.setLayout(LayoutType.MidColumnFullScreen);
    },

    fnOnMinimize: function () {
      const oFCL = this.getView().getParent().getParent();
      // restore to two-columns (mid expanded)
      oFCL.setLayout(LayoutType.TwoColumnsMidExpanded);
    },

    fnOnClose: function () {
      const oRouter = sap.ui.core.UIComponent.getRouterFor(this);
      oRouter.navTo("View1", { layout: "OneColumn" });
    },
    // ========================================Delete=========================================

    onDelete: function () {
      // 1. Grab the shared tree model
      const oCompModel = this.getOwnerComponent().getModel("oJsonGOModel");
      const oData = oCompModel.getData();
      const sPath = this._sBranchPath;                         // "/nodeRoot/…"
      const oNode = oCompModel.getProperty(sPath);            // the JS object to remove

      // 2. Recursive helper to remove the node
      function removeNode(aNodes, oTarget) {
        for (let i = 0; i < aNodes.length; i++) {
          if (aNodes[i] === oTarget) {
            aNodes.splice(i, 1);
            return true;
          }
          if (aNodes[i].children) {
            if (removeNode(aNodes[i].children, oTarget)) {
              return true;
            }
          }
        }
        return false;
      }

      // 3. Attempt deletion from the root array (adjust if your root differs)
      const bDeleted = removeNode(oData.nodeRoot || [], oNode);

      if (bDeleted) {
        // 4. Push updated data back into the model & persist
        oCompModel.setData(oData);
        localStorage.setItem("savedTreeData", JSON.stringify(oData));

        sap.m.MessageToast.show("Branch deleted successfully!");

        // 5. Turn off any edit mode, if set
        this.getView().getModel("formGeneral").setProperty("/editable", false);

      } else {
        sap.m.MessageToast.show("Failed to delete branch. Please try again.");
      }
    },

    // =======================================Edit=================================================
    onEdit() {
      const oFM = this.getView().getModel("formGeneral");
      oFM.setProperty("/editable", !oFM.getProperty("/editable"));
    },    

    onSave: function () {
      const oFM = this.getView().getModel("formGeneral");
      const oBM = this.getView().getModel("branchModel");
      const oCompModel = this.getOwnerComponent().getModel("oJsonGOModel");

      // 1. Read the mandatory values
      const sBranchCode = oBM.getProperty("/BranchCode");
      const sBranchName = oBM.getProperty("/branchName");
      const sDesc = oBM.getProperty("/Description");

      // 2. Validate all mandatory fields
      if (!sBranchCode || !sBranchName || !sDesc) {
        MessageBox.error("Please fill all mandatory fields before saving.", {
          title: "Error"
        });
        return;
      }

      // 3. All good—write back to your tree model
      oCompModel.setProperty(this._sBranchPath + "/BranchCode", sBranchCode);
      oCompModel.setProperty(this._sBranchPath + "/ObjectName", sBranchName);
      oCompModel.setProperty(this._sBranchPath + "/Description", sDesc);

      // 4. Persist if needed
      localStorage.setItem("savedTreeData", JSON.stringify(oCompModel.getData()));

      MessageToast.show("Branch Saved Successfully");

      // 5. Reset edit mode
      oFM.setProperty("/editable", false);

    },
    onCancel: function () {
      const oBM = this.getView().getModel("branchModel");
      const oFM = this.getView().getModel("formGeneral");
    
      // 1. Grab the current branchName so we don’t lose it
      const sBranchName = oBM.getProperty("/branchName");
      
      // 2. Clear the other editable fields
      oBM.setProperty("/BranchCode", "");
      oBM.setProperty("/Description", "");
    
      // 3. Make sure branchName stays put
      oBM.setProperty("/branchName", sBranchName);
    
      // 4. Turn off edit mode
      oFM.setProperty("/editable", false);
    
      MessageToast.show("Changes discarded (fields cleared except Branch Name)");
    }
    
  });
});
