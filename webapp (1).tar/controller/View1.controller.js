
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "project1/model/TreeData",
    "project1/model/FinanceData",
    "project1/model/HRData"

], (Controller, JSONModel, MessageToast, TreeData, FinanceData, HRData) => {
    "use strict";

    return Controller.extend("project1.controller.View1", {
        onInit() {

            this._oSelectedBranch = null;
            this._oMoveTargetBranch = null;
            this._allowedTopName = null;
            this.oRouter = this.getOwnerComponent().getRouter();
            this.fnloadTreeData("learning");
        },

        onAfterRendering: function () {
            var oNextUIState = this.getOwnerComponent().getHelper().getNextUIState(1);
            this.oRouter.navTo("View2", { branch: "0", layout: oNextUIState.layout });
        },


        // ==================================SegmentedButton for hierarchy type switching=======================

         // Extracted helper to load any tree
    fnloadTreeData: function (sKey) {
        let oData;
        switch (sKey) {
          case "learning":
            oData = TreeData.getData();
            break;
          case "finance":
            oData = FinanceData.getData();
            break;
          case "hr":
            oData = HRData.getData();
            break;
        }
  
        const oTreeModel = new JSONModel(oData);
  
        // always set on both view AND component
        this.getView().setModel(oTreeModel, "oJsonGOModel");
        this.getOwnerComponent().setModel(oTreeModel, "oJsonGOModel");
  
        // clear any selection in the tree
        this.fnClearSelection();
      },
       
      onHierarchySelectionChange(oEvent) {
        const sKey = oEvent.getParameter("item").getKey();
  
        // 2) reuse helper
        this.fnloadTreeData(sKey);
  
        // then navigate
        const oNextUIState = this.getOwnerComponent().getHelper().getNextUIState(1);
        this.oRouter.navTo("View2", {
          branch: sKey,
          layout: oNextUIState.layout
        });
      },

        // ==================================================Expand Collaps====================================


        fnOnExpand: function (oEvent) {
            var that = this;
            var oTree = that.getView().byId("HierarchyTree");
            oTree.expandToLevel(999);

            var aSelectedItems = oTree.getSelectedItems();
            aSelectedItems.forEach(function (oItem) {
                that._selectAllChildrenUI(oTree, oItem);
            });
        },

        /**
         * Function For Collapse All
         * @function
         * @private
         */
        fnOnCollapse: function (oEvent) {
            var oTree = oEvent.getSource().getParent().getParent();
            oTree.collapseAll();
        },

        // =======================================================Navigation=================================================

        fnOnSelectionChange: function (oEvent) {
            const oItem = oEvent.getParameter("listItem");
            if (!oItem) { this._oSelectedBranch = null; return; }

            const oModel = this.getView().getModel("oJsonGOModel");
            const oCtx = oItem.getBindingContext("oJsonGOModel");
            const sPath = oCtx.getPath();               // e.g. "/nodeRoot/children/0/children/2"
            const oSel = oCtx.getObject();
            const sParentPath = sPath.substring(0, sPath.lastIndexOf("/children"));
            const oParent = oModel.getProperty(sParentPath) || {};

            // your existing recursive-select logic…
            if (this._selectAllChildrenUI) {
                this._selectAllChildrenUI(this.byId("HierarchyTree"), oItem);
            }

            this._oSelectedBranch = oSel;

            // build full payload (including path!)
            const oPayload = {
                path: sPath,
                parentName: oParent.ObjectName || "",
                branchName: oSel.ObjectName,
                BranchCode: oSel.BranchCode,
                LogonLanguage: oSel.LogonLanguage,
                Description: oSel.Description
            };

            const oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            oRouter.navTo("View2", {
                branch: encodeURIComponent(JSON.stringify(oPayload)),
                branch: encodeURIComponent(JSON.stringify(oPayload)),
                layout: "TwoColumnsMidExpanded"
            });
        },

        // ==============================automatically select chiled if root is selected================================


        _selectAllChildrenUI: function (oTree, oSelectedItem) {
            var oSelectedContext = oSelectedItem.getBindingContext("oJsonGOModel");
            if (!oSelectedContext) return;

            var oSelectedData = oSelectedContext.getObject();
            if (!oSelectedData) return;

            var aAllTreeItems = oTree.getItems();

            function selectDescendants(oNodeData) {
                if (!oNodeData.children || oNodeData.children.length === 0) return;

                oNodeData.children.forEach(function (childNode) {
                    var oChildItem = aAllTreeItems.find(function (oItem) {
                        var oContext = oItem.getBindingContext("oJsonGOModel");
                        return oContext && oContext.getObject() === childNode;
                    });

                    // if (oChildItem) {
                    //     oTree.setSelectedItem(oChildItem, true);
                    //     selectDescendants(childNode);
                    // }
                });
            }
            selectDescendants(oSelectedData);
        },
        // ==================================================Clear selection=======================================


        fnClearSelection: function () {
            var oTree = this.byId("HierarchyTree");
            if (!oTree) {
                console.warn("Tree control not found.");
                return;
            }
            // Iterate through each item in the tree and unselect
            var aItems = oTree.getItems();
            aItems.forEach(item => {
                item.setSelected(false);
            });
            // Also, clear the stored selection in the controller
            this._oSelectedBranch = null;
            // sap.m.MessageToast.show("Selection cleared!");
        },

        // ==================================================Search =========================================



        fnSearchBranchAdmin: function (oEvent) {
            var sQuery = oEvent.getParameter("query");
            var oTree = this.byId("HierarchyTree");

            if (!oTree) {
                console.warn("Tree control not found.");
                return;
            }

            var oBinding = oTree.getBinding("items");
            if (sQuery) {
                var oFilter = new sap.ui.model.Filter("ObjectName", sap.ui.model.FilterOperator.Contains, sQuery);
                oBinding.filter([oFilter]);
            } else {
                oBinding.filter([]);
            }
        },

        // =========================================================== Menu==============================================
        fnOnPressMenu: function () {
            var oView = this.getView();
            if (!this._oMenuFragment) {
                this._oMenuFragment = sap.ui.xmlfragment("project1.fragments.Menu", this);
                oView.addDependent(this._oMenuFragment);
            }
            this._oMenuFragment.openBy(this.byId("_IDAssignButtonBranch"));

        },



        // =================================================================Create=======================================
        // Open the create branch dialog.
        fnOnCreateBranch: function () {
            var oView = this.getView();
            if (!this._oCreateBranchDialog) {
                this._oCreateBranchDialog = sap.ui.xmlfragment("project1.fragments.CreateBranch", this);
                oView.addDependent(this._oCreateBranchDialog);
            }
            this._oCreateBranchDialog.open();
        },

        // When branch creation is confirmed, check if a branch is selected.
        // If so, create the new branch as a child of the selected branch; otherwise,
        // add the new branch to the root.
        fnOnConfirmBranch: function () {
            var oTree = this.getView().byId("HierarchyTree");
            var oJsonModel = this.getView().getModel("oJsonGOModel");
            var oData = oJsonModel.getData();

            var sBranchName = sap.ui.getCore().byId("branchNameInput").getValue();
            if (!sBranchName) {
                sap.m.MessageToast.show("Please enter a valid branch name!");
                return;
            }

            var oNewBranch = {
                "ObjectName": sBranchName,
                "children": []
            };

            if (this._oSelectedBranch) {
                if (!this._oSelectedBranch.children) {
                    this._oSelectedBranch.children = [];
                }
                this._oSelectedBranch.children.push(oNewBranch);
            } else {
                oData.nodeRoot.push(oNewBranch);
            }

            localStorage.setItem("savedTreeData", JSON.stringify(oData));
            oJsonModel.setData(oData);
            oTree.getBinding("items").refresh();

            sap.ui.getCore().byId("branchNameInput").setValue("");
            this._oCreateBranchDialog.close();

            sap.m.MessageToast.show(`New branch '${sBranchName}' added successfully!`);

            // Clear selection so checkboxes are reset
            this.fnClearSelection();
        },

        fnOnCancelBranch: function () {
            this._oCreateBranchDialog.close();
        },
        //===================================================== Delete ===========================================


        fnOnDeleteBranch: function () {
            if (!this._oSelectedBranch) {
                sap.m.MessageToast.show("Please select a branch to delete.");
                return;
            }

            var oJsonModel = this.getView().getModel("oJsonGOModel");
            var oData = oJsonModel.getData();

            function removeNode(aNodes, oNodeToRemove) {
                for (var i = 0; i < aNodes.length; i++) {
                    if (aNodes[i] === oNodeToRemove) {
                        aNodes.splice(i, 1);
                        return true;
                    } else if (aNodes[i].children && aNodes[i].children.length > 0) {
                        var bRemoved = removeNode(aNodes[i].children, oNodeToRemove);
                        if (bRemoved) return true;
                    }
                }
                return false;
            }

            var bDeleted = removeNode(oData.nodeRoot, this._oSelectedBranch);
            if (bDeleted) {
                localStorage.setItem("savedTreeData", JSON.stringify(oData));
                oJsonModel.setData(oData);
                this.getView().byId("HierarchyTree").getBinding("items").refresh();
                sap.m.MessageToast.show("Branch deleted successfully!");

                // Clear selection after deletion
                this.fnClearSelection();

                if (this._oMenuFragment) {
                    var oDeleteMenuItem = sap.ui.core.Fragment.byId(this._oMenuFragment.getId(), "_IDGenMenuItem2");
                    if (oDeleteMenuItem) oDeleteMenuItem.setEnabled(false);
                }
            } else {
                sap.m.MessageToast.show("Failed to delete branch. Please try again.");
            }
        },
        // =================================================  Edit  ==================================================

        fnOnEditBranch: function () {
            if (!this._oSelectedBranch) {
                sap.m.MessageToast.show("Please select a branch to edit.");
                return;
            }

            var oView = this.getView();

            // Ensure the dialog is created only once
            if (!this._oEditBranchDialog) {
                this._oEditBranchDialog = sap.ui.xmlfragment("project1.fragments.EditBranch", this);
                oView.addDependent(this._oEditBranchDialog);
            }

            // Fetch the latest branch name
            var oJsonModel = this.getView().getModel("oJsonGOModel");
            var oUpdatedBranch = oJsonModel.getProperty(this._oSelectedBranch.__path);

            // Ensure value is reset before opening dialog
            var oInput = sap.ui.getCore().byId("editBranchNameInput");
            if (oUpdatedBranch) {
                oInput.setValue(oUpdatedBranch.ObjectName);
            } else {
                oInput.setValue(""); // Clear if data is not found
            }

            this._oEditBranchDialog.open();
        },

        fnOnConfirmEditBranch: function () {
            var sNewBranchName = sap.ui.getCore().byId("editBranchNameInput").getValue();

            if (!sNewBranchName) {
                sap.m.MessageToast.show("Please enter a valid name.");
                return;
            }

            // Update the selected branch's name
            this._oSelectedBranch.ObjectName = sNewBranchName;

            // Refresh the model and tree binding
            var oJsonModel = this.getView().getModel("oJsonGOModel");
            oJsonModel.updateBindings();

            // Save the updated data in local storage
            var oData = oJsonModel.getData();
            localStorage.setItem("savedTreeData", JSON.stringify(oData));

            this._oEditBranchDialog.close();
            sap.m.MessageToast.show(`Branch renamed to '${sNewBranchName}' successfully!`);
            this.fnClearSelection();
        },

        fnOnCancelEditBranch: function () {
            this._oEditBranchDialog.close();
        },



        // ===================================================Move===================================================




        fnOnMoveBranch: function () {
            if (!this._oSelectedBranch) {
                MessageToast.show("Select a subbranch to move from the main view first.");
                return;
            }

            var oView = this.getView();
            var oJsonModel = this.getView().getModel("oJsonGOModel");
            var oData = oJsonModel.getData();

            if (oData.nodeRoot.indexOf(this._oSelectedBranch) !== -1) {
                MessageToast.show("Main Branch cannot be moved.");
                return;
            }

            var oAllowedTop = this._findAllowedTop(oData.nodeRoot, this._oSelectedBranch);
            if (!oAllowedTop) {
                MessageToast.show("Unable to determine allowed destination for this branch.");
                return;
            }
            this._allowedTopName = oAllowedTop.ObjectName;

            this._updateActionOnNodes(oData.nodeRoot, this._allowedTopName);
            oJsonModel.refresh();

            if (!this._oMoveBranchDialog) {
                this._oMoveBranchDialog = sap.ui.xmlfragment("project1.fragments.MoveDialog", this);
                this.getView().addDependent(this._oMoveBranchDialog);
            }

            // Reset selection for radio buttons before opening the dialog
            var oRadioGroup = sap.ui.getCore().byId("moveBranchRadioGroup"); // 
            if (oRadioGroup) {
                oRadioGroup.setSelectedIndex(-1); // Clear selection
            }

            this._oMoveTargetBranch = null;
            this._oMoveBranchDialog.open();
        },

        // --- Helper functions to get allowed top branch and update model flags ---

        _findAllowedTop: function (aNodes, oSelectedBranch) {
            var oAllowed = null;
            aNodes.some(function (node) {
                if (this._searchBranch(node, oSelectedBranch)) {
                    oAllowed = node;
                    return true;
                }
                return false;
            }.bind(this));
            return oAllowed;
        },

        _searchBranch: function (oNode, oSelectedBranch) {
            if (oNode === oSelectedBranch) {
                return true;
            }
            if (oNode.children) {
                return oNode.children.some(function (child) {
                    return this._searchBranch(child, oSelectedBranch);
                }.bind(this));
            }
            return false;
        },

        _updateActionOnNodes: function (aNodes, sAllowedTopName) {
            aNodes.forEach(function (node) {
                // Disable the selected branch from appearing as a valid move target
                node.action = node.ObjectName !== this._oSelectedBranch.ObjectName;

                // Enable only the allowed top branch
                if (node.ObjectName === sAllowedTopName) {
                    node.action = true;
                    if (node.children) {
                        this._setActionRecursively(node.children, true, this._oSelectedBranch);
                    }
                } else {
                    node.action = false;
                    if (node.children) {
                        this._setActionRecursively(node.children, false, this._oSelectedBranch);
                    }
                }
            }.bind(this));
        },

        _setActionRecursively: function (aNodes, bAllowed, oSelectedBranch) {
            aNodes.forEach(function (child) {
                // Ensure selected branch is disabled
                child.action = bAllowed && child.ObjectName !== oSelectedBranch.ObjectName;
                if (child.children) {
                    this._setActionRecursively(child.children, bAllowed, oSelectedBranch);
                }
            }.bind(this));
        },


        // --- Handling the move dialog selection ---

        onMoveBranchSelect: function (oEvent) {
            var oSelectedItem = oEvent.getParameter("listItem");
            if (oSelectedItem) {
                this._oMoveTargetBranch = oSelectedItem.getBindingContext("oJsonGOModel").getObject();
                MessageToast.show("Selected destination: " + this._oMoveTargetBranch.ObjectName);
            }
        },

        // (Alternatively, you can also use the radio button’s event.)
        fnSelectRadioMove: function (oEvent) {
            var oRadioButton = oEvent.getSource();
            var oFlexBox = oRadioButton.getParent();
            var oContext = oFlexBox.getBindingContext("oJsonGOModel");
            if (oContext) {
                this._oMoveTargetBranch = oContext.getObject();
                MessageToast.show("Destination selected using radio: " + this._oMoveTargetBranch.ObjectName);
            }
        },

        // --- Confirm and process the move ---

        fnMoveConfirm: function () {
            if (!this._oMoveTargetBranch) {
                MessageToast.show("Please select a destination branch in the move dialog.");
                return;
            }
            if (!this._oSelectedBranch) {
                MessageToast.show("No branch was selected in the main view to move.");
                return;
            }

            // Get the JSON model and its data.
            var oJsonModel = this.getView().getModel("oJsonGOModel");
            var oData = oJsonModel.getData();

            // Remove the selected branch from its current location…
            var oBranchToMove = this._oSelectedBranch;
            var bRemoved = this._removeBranch(oData.nodeRoot, oBranchToMove);
            if (bRemoved) {
                // …then append it under the destination branch.
                if (!this._oMoveTargetBranch.children) {
                    this._oMoveTargetBranch.children = [];
                }
                this._oMoveTargetBranch.children.push(oBranchToMove);
                oJsonModel.setData(oData);
                MessageToast.show("Successfully moved branch to: " + this._oMoveTargetBranch.ObjectName);
            } else {
                MessageToast.show("Failed to move the branch.");
            }

            // Close the dialog and clear the selections.
            this._oMoveBranchDialog.close();
            this._oSelectedBranch = null;
            this._oMoveTargetBranch = null;
            this.fnClearSelection();
        },

        // Recursive helper to remove a branch from the hierarchy.
        _removeBranch: function (aBranches, oBranchToRemove) {
            for (var i = 0; i < aBranches.length; i++) {
                if (aBranches[i] === oBranchToRemove) {
                    aBranches.splice(i, 1);
                    return true;
                }
                if (aBranches[i].children) {
                    var bRemoved = this._removeBranch(aBranches[i].children, oBranchToRemove);
                    if (bRemoved) {
                        return true;
                    }
                }
            }
            return false;
        },

        // --- Cancel Move Operation ---
        fnOnMoveCancel: function () {
            if (this._oMoveBranchDialog) {
                this._oMoveBranchDialog.close();
            }
            this._oMoveTargetBranch = null;
        }
    });
});
