sap.ui.define([], function () {
    "use strict";
    
    return {
        getData: function () {
            return {
                "nodeRoot": [
                    {
                        "ObjectName": "Machine Learning",
                        "children": [
                            {
                                "ObjectName": "Basics",
                                "children": [
                                    { "ObjectName": "Supervised Learning" },
                                    { "ObjectName": "Unsupervised Learning" },
                                    { "ObjectName": "Reinforcement Learning" }
                                ]
                            },
                            {
                                "ObjectName": "Advanced Topics",
                                "children": [
                                    { "ObjectName": "Deep Learning" },
                                    { "ObjectName": "Ensemble Methods" },
                                    { "ObjectName": "Model Interpretability" }
                                ]
                            }
                        ]
                    },
                    {
                        "ObjectName": "SAP Fiori",
                        "children": [
                            {
                                "ObjectName": "Fundamentals",
                                "children": [
                                    { "ObjectName": "UX Design Principles" },
                                    { "ObjectName": "Fiori Launchpad Basics" },
                                    { "ObjectName": "SAPUI5 Overview" }
                                ]
                            },
                            {
                                "ObjectName": "Advanced Development",
                                "children": [
                                    { "ObjectName": "Fiori Elements" },
                                    { "ObjectName": "Smart Controls" },
                                    { "ObjectName": "Spaces & Pages" }
                                ]
                            }
                        ]
                    },
                    {
                        "ObjectName": "RAP (Restful ABAP Programming)",
                        "children": [
                            {
                                "ObjectName": "Core Concepts",
                                "children": [
                                    { "ObjectName": "CDS Views" },
                                    { "ObjectName": "Behavior Definition" },
                                    { "ObjectName": "Service Definition" }
                                ]
                            },
                            {
                                "ObjectName": "Advanced RAP",
                                "children": [
                                    { "ObjectName": "Draft Handling" },
                                    { "ObjectName": "Side Effects & Validations" },
                                    { "ObjectName": "Extending RAP Services" }
                                ]
                            }
                        ]
                    },
                    {
                        "ObjectName": "General Learning",
                        "children": [
                            {
                                "ObjectName": "Soft Skills",
                                "children": [
                                    { "ObjectName": "Effective Communication" },
                                    { "ObjectName": "Time Management" }
                                ]
                            },
                            {
                                "ObjectName": "Professional Development",
                                "children": [
                                    { "ObjectName": "Presentation Skills" },
                                    { "ObjectName": "Technical Writing" }
                                ]
                            }
                        ]
                    }
                ]
            };
        }
    };
});
