sap.ui.define([], function () {
    "use strict";
    
    return {
        getData: function () {
            return {
                "nodeRoot": [
                    {
                        "ObjectName": "Recruitment",
                        "children": [
                            {
                                "ObjectName": "Recruitment Manager",
                                "children": [
                                    { "ObjectName": "Manage Job Postings" },
                                    { "ObjectName": "Review Applications" },
                                    { "ObjectName": "Schedule Interviews" }
                                ]
                            },
                            {
                                "ObjectName": "Hiring Specialist",
                                "children": [
                                    { "ObjectName": "Initiate Offer Letters" },
                                    { "ObjectName": "Track Onboarding Status" }
                                ]
                            }
                        ]
                    },
                    {
                        "ObjectName": "Employee Services",
                        "children": [
                            {
                                "ObjectName": "HR Services Representative",
                                "children": [
                                    { "ObjectName": "Manage Employee Records" },
                                    { "ObjectName": "Update Personal Details" },
                                    { "ObjectName": "Handle Employee Inquiries" }
                                ]
                            },
                            {
                                "ObjectName": "Payroll Coordinator",
                                "children": [
                                    { "ObjectName": "Manage Payroll Schedule" },
                                    { "ObjectName": "Update Bank Details" },
                                    { "ObjectName": "Process Salary Adjustments" }
                                ]
                            }
                        ]
                    },
                    {
                        "ObjectName": "Performance Management",
                        "children": [
                            {
                                "ObjectName": "HR Business Partner",
                                "children": [
                                    { "ObjectName": "Set Performance Goals" },
                                    { "ObjectName": "Initiate Reviews" },
                                    { "ObjectName": "Monitor Feedback" }
                                ]
                            },
                            {
                                "ObjectName": "Training Coordinator",
                                "children": [
                                    { "ObjectName": "Assign Training Courses" },
                                    { "ObjectName": "Track Training Completion" },
                                    { "ObjectName": "Evaluate Training Effectiveness" }
                                ]
                            }
                        ]
                    }
                ]
            };
        }
    };
});
