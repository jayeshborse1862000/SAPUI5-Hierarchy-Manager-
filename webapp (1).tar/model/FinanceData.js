sap.ui.define([], function () {
    "use strict";
    
    return {
        getData: function () {
            return {
                "nodeRoot": [
                    {
                        "ObjectName": "Finance",
                        "children": [
                            {
                                "ObjectName": "General Ledger Accountant",
                                "children": [
                                    { "ObjectName": "Manage Banks - Master Data" },
                                    { "ObjectName": "Map Format Data for Incoming Files from Banks" },
                                    { "ObjectName": "Test Incoming Format Mappings" }
                                ]
                            },
                            {
                                "ObjectName": "Accounts Receivable Accountant",
                                "children": [
                                    { "ObjectName": "Monitor Payments" },
                                    { "ObjectName": "Manage Automatic Payments" }
                                ]
                            }
                        ]
                    },
                    {
                        "ObjectName": "Budget and Finance",
                        "children": [
                            {
                                "ObjectName": "Internal Sales Representative",
                                "children": [
                                    { "ObjectName": "Monitor Value Chains" },
                                    { "ObjectName": "Monitor Payments" },
                                    { "ObjectName": "Manage Automatic Payments" }
                                ]
                            },
                            {
                                "ObjectName": "Billing Clerk",
                                "children": [
                                    { "ObjectName": "Monitor Condition Contracts - Customers" },
                                    { "ObjectName": "Condition Contract (Version 2)" },
                                    { "ObjectName": "Manage Condition Contracts - External Commissions" }
                                ]
                            }
                        ]
                    },
                    {
                        "ObjectName": "Sales",
                        "children": [
                            {
                                "ObjectName": "Internal Sales Representative",
                                "children": [
                                    { "ObjectName": "Invoice List" },
                                    { "ObjectName": "Sales Order Fulfillment Issues (Version 2)" },
                                    { "ObjectName": "Sales Contract Fulfillment Rates" },
 
                                ]
                            },
                            {
                                "ObjectName": "Order Fulfillment Manager",
                                "children": [
                                    { "ObjectName": "Configure Order Fulfillment Responsibilities" },
                                    { "ObjectName": "Configure Alternative Control" },
                                    { "ObjectName": "Configure Product Allocation" }
                                ]
                            }
                        ]
                    }
                ]
            };
        }
    };
});
