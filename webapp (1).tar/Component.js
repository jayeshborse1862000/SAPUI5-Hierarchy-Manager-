

sap.ui.define([
    "sap/ui/core/UIComponent",
    "project1/model/models",
    "sap/ui/model/json/JSONModel",
    "sap/f/library",
    "sap/f/FlexibleColumnLayoutSemanticHelper",
    "sap/base/util/UriParameters",
], (UIComponent, models, JSONModel, library, FlexibleColumnLayoutSemanticHelper, UriParameters) => {
    "use strict";
    var LayoutType = library.LayoutType;
    return UIComponent.extend("project1.Component", {
        metadata: {
            manifest: "json",
            interfaces: [
                "sap.ui.core.IAsyncContentCreation"
            ]
        },

        init() {
           
            UIComponent.prototype.init.apply(this, arguments);

            // empty tree model on component
            const oEmptyTree = new JSONModel({});
            this.setModel(oEmptyTree, "oJsonGOModel");

            // device model & router
            this.setModel(models.createDeviceModel(), "device");
            this.getRouter().initialize();
        },
        getHelper: function () {
            var oFCL = this.getRootControl().byId("fcl"),
                oParams = UriParameters.fromQuery(location.search),
                oSettings = {
                    defaultTwoColumnLayoutType: LayoutType.TwoColumnsMidExpanded,
                    defaultThreeColumnLayoutType: LayoutType.ThreeColumnsMidExpanded,
                    mode: oParams.get("mode"),
                    initialColumnsCount: 2,
                    maxColumnsCount: oParams.get("max")
                };
            return FlexibleColumnLayoutSemanticHelper.getInstanceFor(oFCL, oSettings);
        },

    });
});

